<?php
  // define ('NOM',"concep3t_admin");
  // define ('PASSE', "admin");
  // define ('SERVEUR', "localhost");
  // define ('BASE', "concep16_diablos");
  
  // define ('NOM',"concep16tionweb");
  // define ('PASSE', "]FH(.{~TIWxw");
  // define ('SERVEUR', "localhost");
  // define ('BASE', "concep16_diablos");

  define ('NOM',"root");
  define ('PASSE', "");
  define ('SERVEUR', "localhost");
  define ('BASE', "concep16_diablos");
?>