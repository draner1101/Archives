<?php 
echo'toto';
?>
<html>
<head>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>
<body>
<script>
var ads = <?php 
echo $_GET["a"];
?>;
alert(ads);
</script>
</body>
<?php 
echo'toto3';
?>
</html>